import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import random
from datetime import timedelta
import webbrowser
import os
import subprocess
import sys

# ====================== LOGIN SYSTEM ======================
def login_system():
    print("\n" + "="*70)
    print("          FAKE STEAM LOGIN SYSTEM          ")
    print("="*70)

    if not os.path.exists("users"):
        os.makedirs("users")

    while True:
        print("1. Login")
        print("2. Create new account")
        print("3. Exit")
        choice = input("\nChoose (1-3): ").strip()

        if choice == "3":
            print("Goodbye!")
            sys.exit(0)

        username = input("Username: ").strip()
        if not username:
            print("Username cannot be empty.\n")
            continue

        user_folder = f"users/{username}"
        account_file = os.path.join(user_folder, "account.txt")

        if choice == "2":
            if os.path.exists(account_file):
                print("Account already exists! Use option 1 to login.\n")
                continue
            password = input("Choose password: ").strip()
            os.makedirs(user_folder, exist_ok=True)
            with open(account_file, "w") as f:
                f.write(password)
            print(f"\nAccount created successfully! Welcome, {username}!\n")
            return username, user_folder

        elif choice == "1":
            if not os.path.exists(account_file):
                print("Account does not exist. Create one with option 2.\n")
                continue
            password = input("Password: ").strip()
            with open(account_file) as f:
                saved_pass = f.read().strip()
            if saved_pass == password:
                print(f"\nLogin successful! Welcome back, {username}!\n")
                return username, user_folder
            else:
                print("Wrong password. Try again.\n")

username, user_folder = login_system()

# ====================== MAIN APP ======================
class FakeSteam(tk.Tk):
    def __init__(self, username, user_folder):
        super().__init__()
        self.username = username
        self.user_folder = user_folder
        self.title(f"Steam - {username}")
        self.geometry("1920x1060")
        self.configure(bg="#0a0e14")
        self.minsize(900, 600)

        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TProgressbar", background="#ff0000", troughcolor="#1f252e", thickness=20)

        self.min_speed = 20.0
        self.max_speed = 120.0
        self.total_speed_var = tk.StringVar(value="0.0 Mb/s total")

        self.active_downloads = []
        self.installed_games = []
        self.friends = []
        self.currently_playing = None
        self.balance = 100.0
        self.pending_payment_code = None
        self.pending_payment_amount = 0

        self.disk_size = self.load_disk_size()

        self.status_list = ["Online", "Offline", "Away", "Playing Counter-Strike 2", "Playing Dota 2", "Playing GTA V", "In-Game", "Idle", "Watching Stream"]

        self.load_all_data()

        self.top_bar = tk.Frame(self, bg="#0a0e14", height=50)
        self.top_bar.pack(fill="x")
        self.top_bar.pack_propagate(False)

        self.main_frame = tk.Frame(self, bg="#0a0e14")
        self.main_frame.pack(fill="both", expand=True)

        self.store_frame = tk.Frame(self.main_frame, bg="#0a0e14")
        self.library_frame = tk.Frame(self.main_frame, bg="#0a0e14")
        self.downloads_frame = tk.Frame(self.main_frame, bg="#0a0e14")
        self.friends_frame = tk.Frame(self.main_frame, bg="#0a0e14")

        self.create_top_bar()
        self.populate_store()
        self.populate_library()
        self.populate_downloads()
        self.populate_friends()

        self.show_library()
        self.after(100, self.fix_scrolling)
        self.after(1000, self.update_downloads)
        self.after(3000, self.check_running_games)
        self.after(4000, self.update_friends_status)

    def fix_scrolling(self):
        for inner in [self.store_inner, self.library_inner, self.downloads_inner, self.friends_inner]:
            if inner and inner.winfo_exists():
                inner.update_idletasks()
                inner.master.configure(scrollregion=inner.master.bbox("all"))

    def load_disk_size(self):
        path = os.path.join(self.user_folder, "disk_size.txt")
        if os.path.exists(path):
            with open(path) as f:
                try:
                    return float(f.read().strip())
                except:
                    pass
        while True:
            size = simpledialog.askfloat("Fake Steam Setup", 
                                         f"Welcome {self.username}!\n\nHow much GB does your fake hard drive have?\n(Example: 500)", 
                                         initialvalue=500.0, minvalue=10.0)
            if size is None or size <= 0:
                size = 500.0
            with open(path, "w") as f:
                f.write(str(size))
            return size

    def get_used_space(self):
        used = sum(g["size_gb"] for g in self.installed_games)
        for d in self.active_downloads:
            used += d["game_info"]["size_gb"]
        return used

    def load_all_data(self):
        path = "games.txt"
        if os.path.exists(path):
            self.available_games = []
            with open(path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        parts = line.split(',')
                        name = parts[0]
                        gb = float(parts[1])
                        cost = float(parts[2]) if len(parts) > 2 else 0
                        appid = int(parts[3]) if len(parts) > 3 and parts[3] else None
                        exe = parts[4] if len(parts) > 4 else ""
                        self.available_games.append({"name": name, "size_gb": gb, "color": "#1b2128", "cost": cost, "appid": appid, "exe": exe})
        else:
            self.available_games = [
                {"name": "Counter-Strike 2", "size_gb": 15, "color": "#1b2128", "cost": 0, "appid": 730, "exe": "cs2.exe"},
                {"name": "Dota 2", "size_gb": 5, "color": "#1b2128", "cost": 0, "appid": 570, "exe": "dota2.exe"},
                {"name": "GTA V", "size_gb": 105, "color": "#1b2128", "cost": 29.99, "appid": 271590, "exe": "GTA5.exe"},
                {"name": "Elden Ring", "size_gb": 60, "color": "#1b2128", "cost": 59.99, "appid": 1245620, "exe": ""},
                {"name": "Black Myth: Wukong", "size_gb": 45, "color": "#1b2128", "cost": 59.99, "appid": 2358720, "exe": ""},
                {"name": "Portal 2", "size_gb": 2, "color": "#1b2128", "cost": 0, "appid": 620, "exe": ""},
            ]
            with open(path, "w") as f:
                for g in self.available_games:
                    app = str(g["appid"]) if g["appid"] else ""
                    exe = g["exe"]
                    f.write(f"{g['name']},{g['size_gb']},{g['cost']},{app},{exe}\n")

        base = self.user_folder
        p = os.path.join(base, "balance.txt")
        if os.path.exists(p):
            with open(p) as f:
                try: self.balance = float(f.read().strip())
                except: self.balance = 100.0
        else:
            self.save_balance()

        p = os.path.join(base, "installed.txt")
        if os.path.exists(p):
            with open(p) as f:
                for line in f:
                    name = line.strip()
                    if name:
                        for g in self.available_games:
                            if g["name"] == name:
                                self.installed_games.append(g.copy())
                                break

        p = os.path.join(base, "friends.txt")
        if os.path.exists(p):
            with open(p) as f:
                for line in f:
                    parts = line.strip().split('|')
                    if len(parts) == 2:
                        self.friends.append({"name": parts[0], "status": parts[1]})

    def save_balance(self):
        with open(os.path.join(self.user_folder, "balance.txt"), "w") as f:
            f.write(str(self.balance))

    def save_installed(self):
        with open(os.path.join(self.user_folder, "installed.txt"), "w") as f:
            for g in self.installed_games:
                f.write(g["name"] + "\n")

    def save_friends(self):
        with open(os.path.join(self.user_folder, "friends.txt"), "w") as f:
            for friend in self.friends:
                f.write(f"{friend['name']}|{friend['status']}\n")

    def create_scrollable_frame(self, container):
        canvas = tk.Canvas(container, bg="#0a0e14", highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#0a0e14")
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", on_mousewheel)
        return scrollable_frame

    def create_top_bar(self):
        logo = tk.Label(self.top_bar, text="STEAM", font=("Arial", 22, "bold"), fg="#66c0f4", bg="#0a0e14")
        logo.pack(side="left", padx=30, pady=8)

        nav = tk.Frame(self.top_bar, bg="#0a0e14")
        nav.pack(side="left", pady=8)
        ttk.Button(nav, text="STORE", width=10, command=self.show_store).pack(side="left", padx=4)
        ttk.Button(nav, text="LIBRARY", width=10, command=self.show_library).pack(side="left", padx=4)
        ttk.Button(nav, text="DOWNLOADS", width=10, command=self.show_downloads).pack(side="left", padx=4)
        ttk.Button(nav, text="FRIENDS", width=10, command=self.show_friends).pack(side="left", padx=4)

        right = tk.Frame(self.top_bar, bg="#0a0e14")
        right.pack(side="right", padx=30)

        self.wallet_label = tk.Label(right, text=f"${self.balance:.2f}", font=("Arial", 11, "bold"), fg="#2ecc71", bg="#0a0e14", cursor="hand2")
        self.wallet_label.pack(side="left", padx=15)
        self.wallet_label.bind("<Button-1>", lambda e: self.show_friends())

        user_frame = tk.Frame(right, bg="#0a0e14")
        user_frame.pack(side="left")

        self.user_label = tk.Label(user_frame, text=f"{self.username}", font=("Arial", 10, "bold"), fg="#66c0f4", bg="#0a0e14")
        self.user_label.pack(anchor="w")
        self.playing_label = tk.Label(user_frame, text="", font=("Arial", 9), fg="#66c0f4", bg="#0a0e14")
        self.playing_label.pack(anchor="w")

        ttk.Button(right, text="Logout", command=self.logout).pack(side="right", padx=10)

    def logout(self):
        if messagebox.askyesno("Logout", "Log out and close Steam?"):
            self.destroy()

    def update_user_status(self):
        if self.currently_playing:
            self.user_label.config(fg="#2ecc71")
            self.playing_label.config(text=f"Playing {self.currently_playing['name']}")
        else:
            self.user_label.config(fg="#66c0f4")
            self.playing_label.config(text="")

    def stop_playing(self):
        self.currently_playing = None
        self.update_user_status()

    def check_running_games(self):
        try:
            output = subprocess.check_output("tasklist", shell=True).decode(errors="ignore").lower()
            for game in self.available_games:
                exe = game.get("exe", "").lower()
                if exe and exe in output:
                    if self.currently_playing != game:
                        self.currently_playing = game
                        self.update_user_status()
                    break
        except:
            pass
        self.after(3000, self.check_running_games)

    def hide_all_frames(self):
        self.store_frame.pack_forget()
        self.library_frame.pack_forget()
        self.downloads_frame.pack_forget()
        self.friends_frame.pack_forget()

    def populate_store(self):
        header = tk.Label(self.store_frame, text="Featured & Recommended", font=("Arial", 20, "bold"), fg="#c6d4df", bg="#0a0e14")
        header.pack(pady=20)
        self.store_inner = self.create_scrollable_frame(self.store_frame)
        row, col = 0, 0
        for game in self.available_games:
            tile = tk.Frame(self.store_inner, bg=game["color"], width=210, height=280, relief="flat")
            tile.grid(row=row, column=col, padx=15, pady=15)
            tile.grid_propagate(False)
            tk.Label(tile, text="🎮", font=("Arial", 80), bg=game["color"], fg="#ffffff").pack(pady=(20, 5))
            tk.Label(tile, text=game["name"], font=("Arial", 13, "bold"), bg=game["color"], fg="#c6d4df").pack()
            price_text = f"${game['cost']:.2f}" if game['cost'] > 0 else "Free"
            tk.Label(tile, text=price_text, font=("Arial", 10), bg=game["color"], fg="#66c0f4").pack(pady=5)
            btn_text = f"Buy ${game['cost']:.2f}" if game['cost'] > 0 else "Install"
            ttk.Button(tile, text=btn_text, command=lambda g=game: self.buy_or_install(g)).pack(pady=15)
            col += 1
            if col > 2:   # 3 games per row
                col = 0
                row += 1

    def buy_or_install(self, game):
        if game['cost'] > 0:
            if self.balance < game['cost']:
                messagebox.showerror("Not Enough Money", f"You need ${game['cost']:.2f} to buy {game['name']}. Current balance: ${self.balance:.2f}")
                return
            self.balance -= game['cost']
            self.save_balance()
            self.wallet_label.config(text=f"${self.balance:.2f}")
        self.start_download(game)

    def show_store(self):
        self.hide_all_frames()
        self.store_frame.pack(fill="both", expand=True)

    def populate_library(self):
        sidebar = tk.Frame(self.library_frame, bg="#0f141b", width=240)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Label(sidebar, text="LIBRARY", font=("Arial", 18, "bold"), fg="#66c0f4", bg="#0f141b").pack(pady=30, padx=20, anchor="w")
        tk.Label(sidebar, text="GAMES", font=("Arial", 12), fg="#c6d4df", bg="#0f141b").pack(pady=8, padx=30, anchor="w")

        content = tk.Frame(self.library_frame, bg="#0a0e14")
        content.pack(side="left", fill="both", expand=True)
        tk.Label(content, text="Your Games", font=("Arial", 22, "bold"), fg="#c6d4df", bg="#0a0e14").pack(anchor="w", padx=40, pady=(30, 10))
        self.library_inner = self.create_scrollable_frame(content)

    def refresh_library_games(self):
        for widget in self.library_inner.winfo_children():
            widget.destroy()
        if not self.installed_games:
            lbl = tk.Label(self.library_inner, text="No games installed yet.\nInstall something from the Store!", font=("Arial", 14), fg="#8ba3c7", bg="#0a0e14", justify="center")
            lbl.pack(pady=120)
            return
        row, col = 0, 0
        for game in self.installed_games:
            tile = tk.Frame(self.library_inner, bg="#1b2128", width=210, height=270, relief="flat")
            tile.grid(row=row, column=col, padx=15, pady=15)
            tile.grid_propagate(False)
            tk.Label(tile, text="🎮", font=("Arial", 60), bg="#1b2128", fg="#ffffff").pack(pady=(20, 5))
            tk.Label(tile, text=game["name"], font=("Arial", 11, "bold"), bg="#1b2128", fg="#c6d4df").pack()
            btn_frame = tk.Frame(tile, bg="#1b2128")
            btn_frame.pack(pady=15)
            ttk.Button(btn_frame, text="Play", command=lambda g=game: self.launch_game(g)).pack(side="left", padx=5)
            ttk.Button(btn_frame, text="Remove", command=lambda g=game: self.delete_game(g)).pack(side="left", padx=5)
            if game['cost'] > 0:
                ttk.Button(btn_frame, text="Refund", command=lambda g=game: self.refund_game(g)).pack(side="left", padx=5)
            col += 1
            if col > 2:   # 3 games per row
                col = 0
                row += 1

    def refund_game(self, game):
        if messagebox.askyesno("Refund", f"Refund {game['name']} for ${game['cost']:.2f}?"):
            self.balance += game['cost']
            self.save_balance()
            self.wallet_label.config(text=f"${self.balance:.2f}")
            self.installed_games.remove(game)
            self.save_installed()
            self.refresh_library_games()
            messagebox.showinfo("Refund", f"Refunded ${game['cost']:.2f} for {game['name']}")

    def show_library(self):
        self.hide_all_frames()
        self.library_frame.pack(fill="both", expand=True)
        self.refresh_library_games()

    def populate_downloads(self):
        title = tk.Label(self.downloads_frame, text="DOWNLOADS", font=("Arial", 24, "bold"), fg="#66c0f4", bg="#0a0e14")
        title.pack(pady=15)
        control = tk.Frame(self.downloads_frame, bg="#0a0e14")
        control.pack(fill="x", padx=30, pady=10)
        tk.Label(control, text="Simulated Internet Speed Range (Mb/s)", font=("Arial", 12, "bold"), fg="#c6d4df", bg="#0a0e14").pack(anchor="w")
        sub = tk.Frame(control, bg="#0a0e14")
        sub.pack(pady=8, anchor="w")
        tk.Label(sub, text="Minimum:", bg="#0a0e14", fg="#c6d4df").pack(side="left")
        self.min_spin = ttk.Spinbox(sub, from_=1, to=2000, width=7, increment=5)
        self.min_spin.set("20")
        self.min_spin.pack(side="left", padx=8)
        tk.Label(sub, text="Maximum:", bg="#0a0e14", fg="#c6d4df").pack(side="left", padx=(15,5))
        self.max_spin = ttk.Spinbox(sub, from_=1, to=2000, width=7, increment=5)
        self.max_spin.set("120")
        self.max_spin.pack(side="left", padx=8)
        tk.Label(sub, text="Mb/s", bg="#0a0e14", fg="#66c0f4").pack(side="left", padx=10)
        ttk.Button(sub, text="Apply Limits", command=self.apply_speed_limits).pack(side="left", padx=20)
        self.total_speed_label = tk.Label(control, textvariable=self.total_speed_var, font=("Arial", 11, "bold"), fg="#66c0f4", bg="#0a0e14")
        self.total_speed_label.pack(anchor="w", pady=5)
        self.downloads_inner = self.create_scrollable_frame(self.downloads_frame)

    def apply_speed_limits(self):
        try:
            self.min_speed = float(self.min_spin.get())
            self.max_speed = float(self.max_spin.get())
            if self.min_speed > self.max_speed:
                self.min_speed, self.max_speed = self.max_speed, self.min_speed
        except:
            pass

    def show_downloads(self):
        self.hide_all_frames()
        self.downloads_frame.pack(fill="both", expand=True)
        self.refresh_downloads()

    def populate_friends(self):
        header = tk.Label(self.friends_frame, text="Friends", font=("Arial", 24, "bold"), fg="#66c0f4", bg="#0a0e14")
        header.pack(pady=15)

        # Add Friend
        add_frame = tk.Frame(self.friends_frame, bg="#0a0e14")
        add_frame.pack(fill="x", padx=40, pady=10)
        tk.Label(add_frame, text="Add Friend:", bg="#0a0e14", fg="#c6d4df").pack(side="left")
        self.friend_entry = ttk.Entry(add_frame, width=30)
        self.friend_entry.pack(side="left", padx=10)
        ttk.Button(add_frame, text="Add Friend", command=self.add_friend).pack(side="left")

        # WALLET
        wallet_box = ttk.LabelFrame(self.friends_frame, text="YOUR WALLET", padding=20)
        wallet_box.pack(fill="x", padx=40, pady=20)

        self.wallet_display = tk.Label(wallet_box, text=f"${self.balance:.2f}", font=("Arial", 28, "bold"), fg="#2ecc71", bg="#1f252e")
        self.wallet_display.pack(pady=10)

        tk.Label(wallet_box, text="Add Money:", font=("Arial", 12), fg="#c6d4df", bg="#1f252e").pack(anchor="w", pady=5)
        self.add_amount_entry = ttk.Entry(wallet_box, width=30, font=("Arial", 12))
        self.add_amount_entry.pack(anchor="w")

        ttk.Button(wallet_box, text="Generate Payment Code", command=self.generate_payment_code).pack(anchor="w", pady=10)

        tk.Label(wallet_box, text="Enter Code:", font=("Arial", 12), fg="#c6d4df", bg="#1f252e").pack(anchor="w", pady=5)
        self.enter_code_entry = ttk.Entry(wallet_box, width=30, font=("Arial", 12))
        self.enter_code_entry.pack(anchor="w")

        ttk.Button(wallet_box, text="Confirm Payment", command=self.confirm_payment).pack(anchor="w", pady=10)

        # Friends list
        tk.Label(self.friends_frame, text="Your Friends", font=("Arial", 14, "bold"), fg="#c6d4df", bg="#0a0e14").pack(anchor="w", padx=40, pady=(20,10))
        self.friends_inner = self.create_scrollable_frame(self.friends_frame)

    def refresh_friends(self):
        for widget in self.friends_inner.winfo_children():
            widget.destroy()
        if not self.friends:
            tk.Label(self.friends_inner, text="No friends yet.\nAdd someone above!", font=("Arial", 14), fg="#8ba3c7", bg="#0a0e14").pack(pady=80)
            return
        for f in self.friends:
            row = tk.Frame(self.friends_inner, bg="#1f252e", pady=10, padx=15)
            row.pack(fill="x", pady=6)
            tk.Label(row, text=f["name"], font=("Arial", 13, "bold"), fg="#c6d4df", bg="#1f252e", width=25, anchor="w").pack(side="left")
            color = "#2ecc71" if "Online" in f["status"] else "#e74c3c" if "Offline" in f["status"] else "#66c0f4"
            tk.Label(row, text=f["status"], font=("Arial", 11), fg=color, bg="#1f252e").pack(side="left", padx=20)
            ttk.Button(row, text="Delete", command=lambda friend=f: self.delete_friend(friend)).pack(side="right")

    def add_friend(self):
        name = self.friend_entry.get().strip()
        if name and not any(f["name"] == name for f in self.friends):
            status = random.choice(self.status_list)
            self.friends.append({"name": name, "status": status})
            self.save_friends()
            self.refresh_friends()
            self.friend_entry.delete(0, tk.END)

    def delete_friend(self, friend):
        if friend in self.friends:
            self.friends.remove(friend)
            self.save_friends()
            self.refresh_friends()

    def update_friends_status(self):
        for f in self.friends:
            if random.random() < 0.35:
                f["status"] = random.choice(self.status_list)
        self.refresh_friends()
        self.after(4000, self.update_friends_status)

    def show_friends(self):
        self.hide_all_frames()
        self.friends_frame.pack(fill="both", expand=True)
        self.refresh_friends()
        self.wallet_display.config(text=f"${self.balance:.2f}")

    def generate_payment_code(self):
        amount_str = self.add_amount_entry.get().strip()
        if not amount_str:
            messagebox.showwarning("Error", "Enter amount first")
            return
        try:
            amount = float(amount_str)
            if amount <= 0: raise ValueError
        except:
            messagebox.showwarning("Error", "Invalid amount")
            return

        self.pending_payment_amount = amount
        self.pending_payment_code = str(random.randint(100000, 999999))

        print("\n" + "="*70)
        print("                 PAYMENT CODE GENERATED                 ")
        print("="*70)
        print(f"Code   : {self.pending_payment_code}")
        print(f"Amount : ${amount:.2f}")
        print("Copy the code above and paste it in the 'Enter Code' field")
        print("="*70 + "\n")

        messagebox.showinfo("Code Generated", "Payment code printed to console (check the CMD window)")

    def confirm_payment(self):
        if not self.pending_payment_code:
            messagebox.showwarning("Error", "Generate a code first")
            return
        entered = self.enter_code_entry.get().strip()
        if entered == self.pending_payment_code:
            self.balance += self.pending_payment_amount
            self.save_balance()
            self.wallet_label.config(text=f"${self.balance:.2f}")
            self.wallet_display.config(text=f"${self.balance:.2f}")
            messagebox.showinfo("Success", f"${self.pending_payment_amount:.2f} added!")
            self.pending_payment_code = None
            self.pending_payment_amount = 0
            self.enter_code_entry.delete(0, tk.END)
            self.add_amount_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Error", "Wrong code")

    def start_download(self, game):
        if any(d["name"] == game["name"] for d in self.active_downloads) or any(g["name"] == game["name"] for g in self.installed_games):
            messagebox.showinfo("Steam", game["name"] + " is already installed or downloading.")
            return

        new_used = self.get_used_space() + game["size_gb"]
        if new_used > self.disk_size:
            free = self.disk_size - self.get_used_space()
            messagebox.showerror("Disk Full", f"Not enough space!\n\nUsed: {self.get_used_space():.1f} GB\nGame: {game['size_gb']:.1f} GB\nFree: {free:.1f} GB")
            return

        total_mb = game["size_gb"] * 1024
        d = {
            "name": game["name"],
            "total_mb": total_mb,
            "downloaded_mb": tk.DoubleVar(value=0.0),
            "progress_var": tk.DoubleVar(value=0.0),
            "percent_var": tk.StringVar(value="0%"),
            "speed_var": tk.StringVar(value="0.0 Mb/s"),
            "eta_var": tk.StringVar(value="--"),
            "paused": False,
            "game_info": game.copy(),
        }
        d["speed"] = random.uniform(self.min_speed, self.max_speed)
        self.active_downloads.append(d)
        self.show_downloads()

    def toggle_pause(self, d):
        d["paused"] = not d["paused"]
        if "pause_btn" in d:
            d["pause_btn"].config(text="Resume" if d["paused"] else "Pause")

    def cancel_download(self, d):
        if d in self.active_downloads:
            self.active_downloads.remove(d)
        self.refresh_downloads()

    def complete_download(self, d):
        if d in self.active_downloads:
            self.active_downloads.remove(d)
        self.installed_games.append(d["game_info"])
        self.save_installed()
        self.refresh_downloads()
        self.refresh_library_games()
        messagebox.showinfo("Steam", d["name"] + " finished downloading!")

    def update_downloads(self):
        to_complete = []
        for d in self.active_downloads:
            if d["paused"]:
                continue
            target = random.uniform(self.min_speed, self.max_speed)
            d["speed"] = d["speed"] * 0.6 + target * 0.4
            increment = d["speed"] * 5.0
            new_dl = min(d["total_mb"], d["downloaded_mb"].get() + increment)
            d["downloaded_mb"].set(new_dl)
            prog = (new_dl / d["total_mb"]) * 100
            d["progress_var"].set(prog)
            d["percent_var"].set("{}%".format(int(prog)))
            d["speed_var"].set("{:.1f} Mb/s".format(d["speed"]))
            remaining = d["total_mb"] - new_dl
            if remaining > 0 and d["speed"] > 1:
                d["eta_var"].set(str(timedelta(seconds=int(remaining / d["speed"]))))
            else:
                d["eta_var"].set("Finishing...")
            if new_dl >= d["total_mb"]:
                to_complete.append(d)
        for d in to_complete:
            self.complete_download(d)
        total = sum(d.get("speed", 0) for d in self.active_downloads if not d.get("paused", False))
        self.total_speed_var.set("{:.1f} Mb/s total".format(total))
        self.after(1000, self.update_downloads)

    def refresh_downloads(self):
        for widget in self.downloads_inner.winfo_children():
            widget.destroy()
        if not self.active_downloads:
            tk.Label(self.downloads_inner, text="No active downloads", font=("Arial", 14), fg="#8ba3c7", bg="#0a0e14").pack(pady=100)
            return
        for d in self.active_downloads:
            row = tk.Frame(self.downloads_inner, bg="#1f252e", pady=12, padx=15)
            row.pack(fill="x", pady=6)
            tk.Label(row, text="🎮", font=("Arial", 40), bg="#1f252e", width=4).pack(side="left")
            info = tk.Frame(row, bg="#1f252e")
            info.pack(side="left", fill="x", expand=True, padx=15)
            tk.Label(info, text=d["name"], font=("Arial", 13, "bold"), fg="#c6d4df", bg="#1f252e", anchor="w").pack(fill="x")
            prog_row = tk.Frame(info, bg="#1f252e")
            prog_row.pack(fill="x", pady=6)
            pb = ttk.Progressbar(prog_row, variable=d["progress_var"], maximum=100, length=420, style="TProgressbar")
            pb.pack(side="left", fill="x", expand=True)
            tk.Label(prog_row, textvariable=d["percent_var"], width=6, font=("Arial", 11, "bold"), fg="#66c0f4", bg="#1f252e").pack(side="left", padx=10)
            details = tk.Frame(info, bg="#1f252e")
            details.pack(fill="x")
            tk.Label(details, textvariable=d["speed_var"], fg="#66c0f4", bg="#1f252e", font=("Arial", 10)).pack(side="left", padx=20)
            tk.Label(details, textvariable=d["eta_var"], fg="#66c0f4", bg="#1f252e", font=("Arial", 10)).pack(side="left")
            btn_frame = tk.Frame(row, bg="#1f252e")
            btn_frame.pack(side="right")
            pause_text = "Resume" if d.get("paused", False) else "Pause"
            pause_btn = ttk.Button(btn_frame, text=pause_text, width=10, command=lambda dd=d: self.toggle_pause(dd))
            pause_btn.pack(side="left", padx=5)
            d["pause_btn"] = pause_btn
            ttk.Button(btn_frame, text="Cancel", width=10, command=lambda dd=d: self.cancel_download(dd)).pack(side="left", padx=5)

    def launch_game(self, game):
        self.currently_playing = game
        self.update_user_status()
        appid = game.get("appid")
        if appid and appid is not None:
            webbrowser.open(f"steam://rungameid/{appid}")
        else:
            messagebox.showinfo("Steam", f"Launching {game['name']}...\n\n(Fake game)")

    def delete_game(self, game):
        if messagebox.askyesno("Remove", f"Remove {game['name']} from library? (no refund)"):
            if game in self.installed_games:
                self.installed_games.remove(game)
                self.save_installed()
                self.refresh_library_games()

if __name__ == "__main__":
    print("Fake Steam started with per-account folders and fixed scrolling")
    app = FakeSteam(username, user_folder)
    app.mainloop()