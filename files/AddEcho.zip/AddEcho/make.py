import os
import random
import json

input_file = "input.txt"

file_name = input("Podaj nazwę pliku wyjściowego (np. wynik.py): ")

colors = [
    "\033[31m",  # czerwony
    "\033[32m",  # zielony
    "\033[33m",  # żółty
    "\033[34m",  # niebieski
    "\033[35m",  # magenta
    "\033[36m",  # cyjan
    "\033[37m"   # biały
]

reset = "\033[0m"

with open(input_file, "r", encoding="utf-8") as f:
    lines = f.readlines()

new_lines = []
new_lines.append("import time")

for line in lines:
    text = line.rstrip("\n")
    safe_text = json.dumps(text)

    color = random.choice(colors)
    sleep_time = round(random.uniform(0.01, 0.5), 3)

    new_lines.append(f'print("{color}" + {safe_text} + "{reset}")')
    new_lines.append(f"time.sleep({sleep_time})")

output_temp = "output.txt"

with open(output_temp, "w", encoding="utf-8") as f:
    for line in new_lines:
        f.write(line + "\n")

if os.path.exists(file_name):
    os.remove(file_name)

os.rename(output_temp, file_name)

print(f"Zapisano jako: {file_name}")