import sys
import requests

buffer = ""

print("COM1 bridge started...", flush=True)

while True:
    ch = sys.stdin.read(1)
    if not ch:
        continue

    buffer += ch

    if ch == '\n':
        line = buffer.strip()
        buffer = ""

        if line.startswith("GET "):
            url = line[4:].strip()
            print(f"Request: {url}", file=sys.stderr, flush=True)

            try:
                r = requests.get(url, timeout=5)
                response = r.text
            except Exception as e:
                response = f"ERROR: {e}"

            sys.stdout.write(response + chr(0x04))
            sys.stdout.flush()