#include <stdint.h>
#include <stddef.h>

#define VGA_WIDTH 80
#define VGA_HEIGHT 25

#define COLOR_BLACK 0x0
#define COLOR_BLUE 0x1
#define COLOR_GREEN 0x2
#define COLOR_CYAN 0x3
#define COLOR_RED 0x4
#define COLOR_MAGENTA 0x5
#define COLOR_BROWN 0x6
#define COLOR_LIGHT_GREY 0x7
#define COLOR_DARK_GREY 0x8
#define COLOR_LIGHT_BLUE 0x9
#define COLOR_LIGHT_GREEN 0xA
#define COLOR_LIGHT_CYAN 0xB
#define COLOR_LIGHT_RED 0xC
#define COLOR_PINK 0xD
#define COLOR_YELLOW 0xE
#define COLOR_WHITE 0xF

#define VGA_DEFAULT_COLOR ((COLOR_BLACK << 4) | COLOR_LIGHT_GREY)
#define VGA_CMD_COLOR ((COLOR_BLACK << 4) | COLOR_LIGHT_CYAN)
#define VGA_INFO_COLOR ((COLOR_BLACK << 4) | COLOR_LIGHT_GREEN)
#define VGA_PANIC_COLOR ((COLOR_RED << 4) | COLOR_WHITE)

#define PORT_KBD_DATA 0x60
#define PORT_KBD_STATUS 0x64
#define PORT_KBD_COMMAND 0x64
#define PORT_COM1 0x3F8

#define CMD_BUF_SIZE 256

static uint16_t* const VGA = (uint16_t*)0xB8000;
static size_t cursor_row = 0;
static size_t cursor_col = 0;
static uint8_t active_color = VGA_DEFAULT_COLOR;
static uint32_t rng_state = 0xC0DEF00Du;

static void vga_draw_frame(size_t x, size_t y, size_t w, size_t h, uint8_t color, const char* title);
static void vga_write_at(size_t x, size_t y, uint8_t color, const char* text);

static inline void outb(uint16_t port, uint8_t value) {
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline void cpuid(uint32_t leaf, uint32_t subleaf, uint32_t* a, uint32_t* b, uint32_t* c, uint32_t* d) {
    __asm__ volatile ("cpuid"
                      : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d)
                      : "a"(leaf), "c"(subleaf));
}

static void serial_init(void) {
    outb(PORT_COM1 + 1, 0x00);
    outb(PORT_COM1 + 3, 0x80);
    outb(PORT_COM1 + 0, 0x03);
    outb(PORT_COM1 + 1, 0x00);
    outb(PORT_COM1 + 3, 0x03);
    outb(PORT_COM1 + 2, 0xC7);
    outb(PORT_COM1 + 4, 0x0B);
}

static int serial_received(void) {
    return inb(PORT_COM1 + 5) & 1;
}

static int serial_is_transmit_empty(void) {
    return inb(PORT_COM1 + 5) & 0x20;
}

static void serial_write_char(char c) {
    while (!serial_is_transmit_empty()) {
    }
    outb(PORT_COM1, (uint8_t)c);
}

static char serial_read_char(void) {
    while (!serial_received()) {
    }
    return (char)inb(PORT_COM1);
}

static int host_fetch_url(const char* url, char* out, size_t out_size) {
    if (out_size < 2) {
        return 0;
    }

    serial_write_char('G');
    serial_write_char('E');
    serial_write_char('T');
    serial_write_char(' ');
    while (*url) {
        serial_write_char(*url++);
    }
    serial_write_char('\n');

    size_t i = 0;
    size_t timeout = 3000000;
    while (timeout--) {
        if (!serial_received()) {
            continue;
        }
        char c = serial_read_char();
        if (c == 0x04) {
            break;
        }
        if (i + 1 < out_size) {
            out[i++] = c;
        }
    }
    out[i] = '\0';
    return i > 0;
}

static size_t strlen(const char* s) {
    size_t len = 0;
    while (s[len] != '\0') {
        len++;
    }
    return len;
}

static int strcmp(const char* a, const char* b) {
    while (*a && (*a == *b)) {
        a++;
        b++;
    }
    return (unsigned char)(*a) - (unsigned char)(*b);
}

static int starts_with(const char* text, const char* prefix) {
    while (*prefix) {
        if (*text++ != *prefix++) {
            return 0;
        }
    }
    return 1;
}

static void u32_to_dec(uint32_t value, char* out, size_t out_size) {
    if (out_size == 0) {
        return;
    }

    if (value == 0) {
        if (out_size > 1) {
            out[0] = '0';
            out[1] = '\0';
        } else {
            out[0] = '\0';
        }
        return;
    }

    char tmp[16];
    size_t i = 0;
    while (value > 0 && i < sizeof(tmp)) {
        tmp[i++] = (char)('0' + (value % 10));
        value /= 10;
    }

    size_t j = 0;
    while (i > 0 && j + 1 < out_size) {
        out[j++] = tmp[--i];
    }
    out[j] = '\0';
}

static uint32_t rng_next(void) {
    rng_state = rng_state * 1664525u + 1013904223u;
    return rng_state;
}

static void delay_approx_ms(uint32_t ms) {
    volatile uint32_t spin = 0;
    for (uint32_t i = 0; i < ms * 12000u; i++) {
        spin += i;
    }
    (void)spin;
}

static void speaker_set_frequency(uint32_t frequency) {
    if (frequency < 20) {
        frequency = 20;
    }
    uint32_t divisor = 1193180u / frequency;
    outb(0x43, 0xB6);
    outb(0x42, (uint8_t)(divisor & 0xFF));
    outb(0x42, (uint8_t)((divisor >> 8) & 0xFF));
}

static void speaker_on(void) {
    uint8_t tmp = inb(0x61);
    if ((tmp & 3) != 3) {
        outb(0x61, (uint8_t)(tmp | 3));
    }
}

static void speaker_off(void) {
    uint8_t tmp = inb(0x61);
    outb(0x61, (uint8_t)(tmp & 0xFC));
}

static void speaker_beep(uint32_t frequency, uint32_t duration_ms) {
    speaker_set_frequency(frequency);
    speaker_on();
    delay_approx_ms(duration_ms);
    speaker_off();
}

static void vga_put_entry_at(char c, uint8_t color, size_t x, size_t y) {
    VGA[y * VGA_WIDTH + x] = ((uint16_t)color << 8) | (uint8_t)c;
}

static void vga_set_color(uint8_t color) {
    active_color = color;
}

static void vga_clear_with_color(uint8_t color) {
    for (size_t y = 0; y < VGA_HEIGHT; y++) {
        for (size_t x = 0; x < VGA_WIDTH; x++) {
            vga_put_entry_at(' ', color, x, y);
        }
    }
    cursor_row = 0;
    cursor_col = 0;
}

static void vga_clear(void) {
    vga_clear_with_color(VGA_DEFAULT_COLOR);
}

static void vga_scroll_if_needed(void) {
    if (cursor_row < VGA_HEIGHT) {
        return;
    }

    for (size_t y = 1; y < VGA_HEIGHT; y++) {
        for (size_t x = 0; x < VGA_WIDTH; x++) {
            VGA[(y - 1) * VGA_WIDTH + x] = VGA[y * VGA_WIDTH + x];
        }
    }

    for (size_t x = 0; x < VGA_WIDTH; x++) {
        vga_put_entry_at(' ', active_color, x, VGA_HEIGHT - 1);
    }

    cursor_row = VGA_HEIGHT - 1;
}

static void putchar(char c) {
    if (c == '\n') {
        cursor_col = 0;
        cursor_row++;
        vga_scroll_if_needed();
        return;
    }

    if (c == '\r') {
        cursor_col = 0;
        return;
    }

    vga_put_entry_at(c, active_color, cursor_col, cursor_row);
    cursor_col++;

    if (cursor_col >= VGA_WIDTH) {
        cursor_col = 0;
        cursor_row++;
        vga_scroll_if_needed();
    }
}

static void puts(const char* s) {
    while (*s) {
        putchar(*s++);
    }
}

static void transition_animation(const char* text, uint8_t color) {
    vga_set_color(color);
    vga_clear_with_color(color);
    vga_write_at(2, VGA_HEIGHT / 2 - 1, color, text);
    vga_write_at(2, VGA_HEIGHT / 2, color, "Please wait...");
    vga_draw_frame(2, VGA_HEIGHT / 2 + 1, 60, 3, color, "Loading");
    for (size_t i = 0; i < 56; i++) {
        vga_put_entry_at(0xDB, color, 4 + i, VGA_HEIGHT / 2 + 2);
        delay_approx_ms(60);
    }
    delay_approx_ms(800);
}

static void vga_draw_rect(size_t x, size_t y, size_t w, size_t h, uint8_t color) {
    for (size_t yy = 0; yy < h; yy++) {
        for (size_t xx = 0; xx < w; xx++) {
            size_t px = x + xx;
            size_t py = y + yy;
            if (px < VGA_WIDTH && py < VGA_HEIGHT) {
                vga_put_entry_at(' ', color, px, py);
            }
        }
    }
}

static void vga_draw_frame(size_t x, size_t y, size_t w, size_t h, uint8_t color, const char* title) {
    if (w < 2 || h < 2) {
        return;
    }

    for (size_t xx = 0; xx < w; xx++) {
        if (x + xx < VGA_WIDTH && y < VGA_HEIGHT) {
            vga_put_entry_at((xx == 0 || xx == w - 1) ? '+' : '-', color, x + xx, y);
        }
        if (x + xx < VGA_WIDTH && y + h - 1 < VGA_HEIGHT) {
            vga_put_entry_at((xx == 0 || xx == w - 1) ? '+' : '-', color, x + xx, y + h - 1);
        }
    }

    for (size_t yy = 1; yy + 1 < h; yy++) {
        if (x < VGA_WIDTH && y + yy < VGA_HEIGHT) {
            vga_put_entry_at('|', color, x, y + yy);
        }
        if (x + w - 1 < VGA_WIDTH && y + yy < VGA_HEIGHT) {
            vga_put_entry_at('|', color, x + w - 1, y + yy);
        }
    }

    if (title) {
        size_t tx = x + 2;
        while (*title && tx + 1 < x + w && tx < VGA_WIDTH && y < VGA_HEIGHT) {
            vga_put_entry_at(*title++, color, tx++, y);
        }
    }
}

static void vga_write_at(size_t x, size_t y, uint8_t color, const char* text) {
    size_t px = x;
    while (*text && px < VGA_WIDTH && y < VGA_HEIGHT) {
        vga_put_entry_at(*text++, color, px++, y);
    }
}

static void print_prompt(void) {
    vga_set_color(VGA_CMD_COLOR);
    puts("broOS");
    vga_set_color(VGA_INFO_COLOR);
    puts("# ");
    vga_set_color(VGA_DEFAULT_COLOR);
}

static char scancode_to_char(uint8_t scancode) {
    static const char map[128] = {
        [0x02] = '1', [0x03] = '2', [0x04] = '3', [0x05] = '4',
        [0x06] = '5', [0x07] = '6', [0x08] = '7', [0x09] = '8',
        [0x0A] = '9', [0x0B] = '0', [0x0C] = '-', [0x0D] = '=',
        [0x10] = 'q', [0x11] = 'w', [0x12] = 'e', [0x13] = 'r',
        [0x14] = 't', [0x15] = 'y', [0x16] = 'u', [0x17] = 'i',
        [0x18] = 'o', [0x19] = 'p', [0x1A] = '[', [0x1B] = ']',
        [0x1E] = 'a', [0x1F] = 's', [0x20] = 'd', [0x21] = 'f',
        [0x22] = 'g', [0x23] = 'h', [0x24] = 'j', [0x25] = 'k',
        [0x26] = 'l', [0x27] = ';', [0x28] = '\'',
        [0x29] = '`', [0x2B] = '\\',
        [0x2C] = 'z', [0x2D] = 'x', [0x2E] = 'c', [0x2F] = 'v',
        [0x30] = 'b', [0x31] = 'n', [0x32] = 'm', [0x33] = ',',
        [0x34] = '.', [0x35] = '/', [0x39] = ' '
    };

    if (scancode < 128) {
        return map[scancode];
    }

    return 0;
}

static void kbd_wait_input_ready(void) {
    while (inb(PORT_KBD_STATUS) & 0x02) {
    }
}

static int keyboard_detect(void) {
    uint8_t status = inb(PORT_KBD_STATUS);

    if ((status & 0xFF) == 0xFF) {
        return 0;
    }

    for (int i = 0; i < 64 && (inb(PORT_KBD_STATUS) & 0x01); i++) {
        (void)inb(PORT_KBD_DATA);
    }

    kbd_wait_input_ready();
    outb(PORT_KBD_COMMAND, 0xAE);

    return 1;
}

static int keyboard_try_read_scancode(uint8_t* out_scancode) {
    uint8_t status = inb(PORT_KBD_STATUS);
    if ((status & 0x01) == 0) {
        return 0;
    }

    if (status & 0x20) {
        (void)inb(PORT_KBD_DATA);
        return 0;
    }

    *out_scancode = inb(PORT_KBD_DATA);
    return 1;
}

static void reboot(void) {
    transition_animation("Restarting broOS...", (COLOR_BLUE << 4) | COLOR_WHITE);

    __asm__ volatile ("cli");

    while (inb(PORT_KBD_STATUS) & 0x02) {
    }

    outb(0x64, 0xFE);
    outb(0xCF9, 0x02);
    outb(0xCF9, 0x06);

    for (;;) {
        __asm__ volatile ("hlt");
    }
}

static void read_cpu_vendor(char vendor[13]) {
    uint32_t a, b, c, d;
    cpuid(0, 0, &a, &b, &c, &d);
    ((uint32_t*)vendor)[0] = b;
    ((uint32_t*)vendor)[1] = d;
    ((uint32_t*)vendor)[2] = c;
    vendor[12] = '\0';
}

static void read_cpu_brand(char brand[49]) {
    uint32_t max_ext, b, c, d;
    cpuid(0x80000000u, 0, &max_ext, &b, &c, &d);

    if (max_ext < 0x80000004u) {
        brand[0] = '\0';
        return;
    }

    uint32_t* p = (uint32_t*)brand;
    for (uint32_t leaf = 0; leaf < 3; leaf++) {
        uint32_t a;
        cpuid(0x80000002u + leaf, 0, &a, &b, &c, &d);
        p[leaf * 4 + 0] = a;
        p[leaf * 4 + 1] = b;
        p[leaf * 4 + 2] = c;
        p[leaf * 4 + 3] = d;
    }
    brand[48] = '\0';
}

static void print_cpu_info(void) {
    uint32_t eax, ebx, ecx, edx;
    char vendor[13];
    char brand[49];
    char family_s[16];
    char model_s[16];
    char stepping_s[16];

    read_cpu_vendor(vendor);
    read_cpu_brand(brand);
    cpuid(1, 0, &eax, &ebx, &ecx, &edx);

    uint32_t stepping = eax & 0xF;
    uint32_t model = (eax >> 4) & 0xF;
    uint32_t family = (eax >> 8) & 0xF;
    uint32_t ext_model = (eax >> 16) & 0xF;
    uint32_t ext_family = (eax >> 20) & 0xFF;

    if (family == 0xF) {
        family += ext_family;
    }
    if (family == 0x6 || family == 0xF) {
        model += (ext_model << 4);
    }

    u32_to_dec(family, family_s, sizeof(family_s));
    u32_to_dec(model, model_s, sizeof(model_s));
    u32_to_dec(stepping, stepping_s, sizeof(stepping_s));

    puts("CPU Vendor: ");
    puts(vendor);
    puts("\nCPU Brand : ");
    if (strlen(brand) > 0) {
        puts(brand);
    } else {
        puts("(niedostepny)");
    }
    puts("\nCPU Family: ");
    puts(family_s);
    puts("\nCPU Model : ");
    puts(model_s);
    puts("\nStepping  : ");
    puts(stepping_s);
    puts("\n");
}

static void panic_screen(const char* reason) {
    vga_set_color(VGA_PANIC_COLOR);
    vga_clear_with_color(VGA_PANIC_COLOR);

    puts("*** KERNEL PANIC ***\n\n");
    puts("Powod: ");
    if (reason && strlen(reason) > 0) {
        puts(reason);
    } else {
        puts("(brak)");
    }
    puts("\n\n");
    print_cpu_info();
    puts("\nAuto-reboot za 5 sekund...\n");

    for (int sec = 5; sec > 0; sec--) {
        char num[4];
        u32_to_dec((uint32_t)sec, num, sizeof(num));
        puts("Restart za: ");
        puts(num);
        puts("s\n");
        delay_approx_ms(1000);
    }

    reboot();
}

static void waterfall_mode(void) {
    static const uint8_t rainbow[] = {
        (COLOR_BLACK << 4) | COLOR_LIGHT_RED,
        (COLOR_BLACK << 4) | COLOR_YELLOW,
        (COLOR_BLACK << 4) | COLOR_LIGHT_GREEN,
        (COLOR_BLACK << 4) | COLOR_LIGHT_CYAN,
        (COLOR_BLACK << 4) | COLOR_LIGHT_BLUE,
        (COLOR_BLACK << 4) | COLOR_PINK,
        (COLOR_BLACK << 4) | COLOR_WHITE
    };

    uint8_t drops[VGA_WIDTH];
    for (size_t x = 0; x < VGA_WIDTH; x++) {
        drops[x] = (uint8_t)(rng_next() % VGA_HEIGHT);
    }

    vga_clear_with_color((COLOR_BLACK << 4) | COLOR_BLACK);
    speaker_on();
    speaker_set_frequency(440);

    for (;;) {
        for (size_t x = 0; x < VGA_WIDTH; x++) {
            uint8_t y = drops[x];
            char ch = (char)(33 + (rng_next() % 94));
            uint8_t color = rainbow[(rng_next() + (uint32_t)x) % (sizeof(rainbow) / sizeof(rainbow[0]))];

            vga_put_entry_at(ch, color, x, y);

            size_t clear_row = (y + 1) % VGA_HEIGHT;
            vga_put_entry_at(' ', (COLOR_BLACK << 4) | COLOR_BLACK, x, clear_row);

            drops[x] = (uint8_t)((y + 1) % VGA_HEIGHT);
        }

        speaker_on();
        speaker_set_frequency(80u + (rng_next() % 1200u));

        uint8_t scancode;
        if (keyboard_try_read_scancode(&scancode)) {
            if ((scancode & 0x80) == 0 && scancode == 0x2E) {
                speaker_off();
                vga_clear();
                return;
            }
        }

        delay_approx_ms(45);
    }
}

typedef struct {
    size_t x;
    size_t y;
    size_t w;
    size_t h;
    const char* title;
    const char* l1;
    const char* l2;
    const char* l3;
    int minimized;
} GuiWindow;

static void mouse_write(uint8_t value) {
    kbd_wait_input_ready();
    outb(PORT_KBD_COMMAND, 0xD4);
    kbd_wait_input_ready();
    outb(PORT_KBD_DATA, value);
}

static uint8_t mouse_read(void) {
    while ((inb(PORT_KBD_STATUS) & 0x01) == 0) {
    }
    return inb(PORT_KBD_DATA);
}

static void mouse_init(void) {
    uint8_t status;

    kbd_wait_input_ready();
    outb(PORT_KBD_COMMAND, 0xA8);

    kbd_wait_input_ready();
    outb(PORT_KBD_COMMAND, 0x20);
    status = inb(PORT_KBD_DATA);
    status |= 0x02;
    status |= 0x01;

    kbd_wait_input_ready();
    outb(PORT_KBD_COMMAND, 0x60);
    kbd_wait_input_ready();
    outb(PORT_KBD_DATA, status);

    mouse_write(0xF6);
    (void)mouse_read();
    mouse_write(0xF4);
    (void)mouse_read();
}

static int point_in_rect(int px, int py, size_t x, size_t y, size_t w, size_t h) {
    return px >= (int)x && py >= (int)y && px < (int)(x + w) && py < (int)(y + h);
}

static void draw_gui_window(const GuiWindow* w, uint8_t frame_color, uint8_t body_color) {
    if (w->minimized) {
        return;
    }

    vga_draw_rect(w->x, w->y, w->w, w->h, body_color);
    vga_draw_frame(w->x, w->y, w->w, w->h, frame_color, w->title);
    if (w->h > 1 && w->w > 6) {
        vga_put_entry_at('[', frame_color, w->x + w->w - 4, w->y);
        vga_put_entry_at('-', frame_color, w->x + w->w - 3, w->y);
        vga_put_entry_at(']', frame_color, w->x + w->w - 2, w->y);
    }

    if (w->h > 3) {
        vga_write_at(w->x + 2, w->y + 2, body_color, w->l1);
    }
    if (w->h > 4) {
        vga_write_at(w->x + 2, w->y + 3, body_color, w->l2);
    }
    if (w->h > 5) {
        vga_write_at(w->x + 2, w->y + 4, body_color, w->l3);
    }
}

static void shutdown_system(void) {
    transition_animation("Shutting down broOS...", (COLOR_BLACK << 4) | COLOR_LIGHT_GREY);
    __asm__ volatile ("cli");
    outb(0xF4, 0x00); // some emulators
    outb(0xB2, 0x00); // APM hint
    __asm__ volatile ("outw %0, %1" : : "a"((uint16_t)0x2000), "Nd"((uint16_t)0x604)); // QEMU/Bochs ACPI
    __asm__ volatile ("outw %0, %1" : : "a"((uint16_t)0x2000), "Nd"((uint16_t)0xB004));
    for (;;) {
        __asm__ volatile ("hlt");
    }
}

static void gui_reset_windows(GuiWindow windows[4], char* bl1, char* bl2, char* bl3) {
    windows[0] = (GuiWindow){14, 2, 30, 9, "Inventory.exe", "HP: 100   Mana: 50", "Sword +2, Shield +1", "Quest: Defeat Kernel Bug", 0};
    windows[1] = (GuiWindow){44, 3, 34, 11, "WorldMap.exe", "[Town]-[Forest]-[Dungeon]", "Player: @  Enemies: 3", "Drag windows with mouse", 0};
    windows[2] = (GuiWindow){16, 13, 28, 8, "Chat.log", "> NPC: Welcome, hero!", "> You: show me loot", "> NPC: press C to logout", 0};
    windows[3] = (GuiWindow){18, 4, 58, 12, "Browser.exe", bl1, bl2, bl3, 1};
}

static void gui_redraw_desktop(GuiWindow windows[4], int start_menu_open, const char* browser_url) {
    const uint8_t desktop = (COLOR_BLUE << 4) | COLOR_CYAN;
    const uint8_t taskbar = (COLOR_DARK_GREY << 4) | COLOR_WHITE;
    const uint8_t win_frame = (COLOR_LIGHT_GREY << 4) | COLOR_WHITE;
    const uint8_t win_body = (COLOR_LIGHT_GREY << 4) | COLOR_BLACK;
    const uint8_t menu_bg = (COLOR_BLACK << 4) | COLOR_LIGHT_GREY;

    vga_clear_with_color(desktop);
    for (size_t i = 0; i < 4; i++) {
        draw_gui_window(&windows[i], win_frame, win_body);
    }
    if (!windows[3].minimized) {
        vga_write_at(windows[3].x + 2, windows[3].y + windows[3].h - 2, win_body, "URL: ");
        vga_write_at(windows[3].x + 7, windows[3].y + windows[3].h - 2, win_body, browser_url);
    }

    // Desktop icons (left dock)
    vga_draw_rect(0, 0, 12, VGA_HEIGHT - 2, (COLOR_BLUE << 4) | COLOR_LIGHT_BLUE);
    vga_draw_rect(1, 2, 7, 4, win_body);
    vga_draw_frame(1, 1, 7, 4, win_frame, NULL);
    vga_write_at(3, 2, win_body, "C");
    vga_write_at(1, 6, desktop, "Console");

    vga_draw_rect(1, 8, 7, 4, win_body);
    vga_draw_frame(1, 7, 7, 4, win_frame, NULL);
    vga_write_at(3, 8, win_body, "B");
    vga_write_at(1, 12, desktop, "Browser");

    vga_draw_rect(1, 14, 7, 4, win_body);
    vga_draw_frame(1, 13, 7, 4, win_frame, NULL);
    vga_write_at(3, 14, win_body, "W");
    vga_write_at(1, 18, desktop, "Water");

    vga_draw_rect(0, VGA_HEIGHT - 2, VGA_WIDTH, 2, taskbar);
    vga_write_at(1, VGA_HEIGHT - 2, taskbar, "[Start]  Mouse drag/minimize  C=Console");

    size_t task_x = 10;
    for (size_t i = 0; i < 4; i++) {
        if (windows[i].minimized) {
            vga_write_at(task_x, VGA_HEIGHT - 1, taskbar, "[");
            task_x += 1;
            vga_write_at(task_x, VGA_HEIGHT - 1, taskbar, windows[i].title);
            task_x += strlen(windows[i].title);
            vga_write_at(task_x, VGA_HEIGHT - 1, taskbar, "]");
            task_x += 2;
        }
    }

    if (start_menu_open) {
        vga_draw_rect(0, VGA_HEIGHT - 9, 18, 7, menu_bg);
        vga_draw_frame(0, VGA_HEIGHT - 9, 18, 7, taskbar, "Start");
        vga_write_at(2, VGA_HEIGHT - 7, menu_bg, "Console");
        vga_write_at(2, VGA_HEIGHT - 6, menu_bg, "Reboot");
        vga_write_at(2, VGA_HEIGHT - 5, menu_bg, "Shutdown");
        vga_write_at(2, VGA_HEIGHT - 4, menu_bg, "Browser");
    }
}

typedef struct {
    int open;
    size_t x;
    size_t y;
    size_t w;
    size_t h;
    char input[CMD_BUF_SIZE];
    size_t input_len;
    char lines[8][64];
    size_t line_count;
} GuiConsole;

static void gui_console_push_line(GuiConsole* c, const char* text) {
    if (!text) {
        return;
    }
    if (c->line_count < 8) {
        c->line_count++;
    }
    for (size_t i = 1; i < c->line_count; i++) {
        for (size_t j = 0; j < sizeof(c->lines[0]); j++) {
            c->lines[i - 1][j] = c->lines[i][j];
        }
    }
    size_t j = 0;
    while (text[j] && j + 1 < sizeof(c->lines[0])) {
        c->lines[c->line_count - 1][j] = text[j];
        j++;
    }
    c->lines[c->line_count - 1][j] = '\0';
}

static void gui_console_draw(const GuiConsole* c, uint8_t frame, uint8_t body) {
    if (!c->open) {
        return;
    }
    vga_draw_rect(c->x, c->y, c->w, c->h, body);
    vga_draw_frame(c->x, c->y, c->w, c->h, frame, "Console");
    for (size_t i = 0; i < c->line_count && i + 3 < c->h; i++) {
        vga_write_at(c->x + 2, c->y + 2 + i, body, c->lines[i]);
    }
    vga_write_at(c->x + 2, c->y + c->h - 2, body, "> ");
    vga_write_at(c->x + 4, c->y + c->h - 2, body, c->input);
}

static void gui_console_exec(GuiConsole* c, const char* cmd, int* want_shutdown, int* want_reboot_gui) {
    if (strcmp(cmd, "help") == 0) {
        gui_console_push_line(c, "help clear/cls echo X reboot shutdown");
        gui_console_push_line(c, "panic X waterfall cpuinfo version rand");
        return;
    }
    if (strcmp(cmd, "clear") == 0 || strcmp(cmd, "cls") == 0) {
        c->line_count = 0;
        return;
    }
    if (starts_with(cmd, "echo") && cmd[4] == ' ') {
        gui_console_push_line(c, cmd + 5);
        return;
    }
    if (strcmp(cmd, "version") == 0) {
        gui_console_push_line(c, "broOS 0.3-dev");
        return;
    }
    if (strcmp(cmd, "rand") == 0) {
        char n[16];
        u32_to_dec(rng_next() % 100000u, n, sizeof(n));
        gui_console_push_line(c, n);
        return;
    }
    if (strcmp(cmd, "cpuinfo") == 0) {
        char vendor[13];
        read_cpu_vendor(vendor);
        gui_console_push_line(c, vendor);
        return;
    }
    if (starts_with(cmd, "browser ") && strlen(cmd) > 8) {
        char response[64];
        if (host_fetch_url(cmd + 8, response, sizeof(response))) {
            gui_console_push_line(c, response);
        } else {
            gui_console_push_line(c, "Brak host-bridge dla browser.");
        }
        return;
    }
    if (starts_with(cmd, "panic")) {
        const char* reason = (cmd[5] == ' ') ? cmd + 6 : "";
        panic_screen(reason);
        return;
    }
    if (strcmp(cmd, "waterfall") == 0) {
        waterfall_mode();
        gui_console_push_line(c, "waterfall done");
        return;
    }
    if (strcmp(cmd, "shutdown") == 0) {
        *want_shutdown = 1;
        return;
    }
    if (strcmp(cmd, "reboot") == 0) {
        (void)want_reboot_gui;
        reboot();
        return;
    }
    if (strcmp(cmd, "gui") == 0) {
        gui_console_push_line(c, "Juz jestes w GUI.");
        return;
    }
    gui_console_push_line(c, "Nieznana komenda.");
}

static void browser_set_lines(char* l1, char* l2, char* l3, const char* text) {
    char* lines[3] = {l1, l2, l3};
    size_t li = 0;
    size_t col = 0;
    for (size_t i = 0; i < 63; i++) {
        l1[i] = l2[i] = l3[i] = '\0';
    }
    while (*text && li < 3) {
        if (*text == '\n' || col >= 58) {
            lines[li][col] = '\0';
            li++;
            col = 0;
            if (*text == '\n') {
                text++;
            }
            continue;
        }
        lines[li][col++] = *text++;
    }
    if (li < 3) {
        lines[li][col] = '\0';
    }
}

static void gui_mode(void) {
    const uint8_t cursor_color = (COLOR_BLACK << 4) | COLOR_WHITE;

    GuiWindow windows[4];
    char browser_line1[64] = "Browser host bridge";
    char browser_line2[64] = "Wpisz URL i Enter";
    char browser_line3[64] = "";
    char browser_url[64] = "example.com";
    size_t browser_url_len = 11;
    int browser_focus = 0;

    int mouse_x = (int)(VGA_WIDTH / 2);
    int mouse_y = (int)(VGA_HEIGHT / 2);
    uint8_t mouse_cycle = 0;
    uint8_t mouse_packet[3] = {0};
    int left_down = 0;
    int prev_left_down = 0;
    int drag_index = -1;
    int drag_off_x = 0;
    int drag_off_y = 0;
    int drag_new_x = 0;
    int drag_new_y = 0;
    int drag_pending = 0;
    int start_menu_open = 0;
    int dirty = 1;
    GuiConsole console = {0, 18, 6, 44, 14, {0}, 0, {{0}}, 0};
    int want_shutdown = 0;
    int want_reboot_gui = 0;

    size_t prev_mouse_x = (size_t)mouse_x;
    size_t prev_mouse_y = (size_t)mouse_y;
    uint16_t prev_mouse_cell = VGA[prev_mouse_y * VGA_WIDTH + prev_mouse_x];

    gui_reset_windows(windows, browser_line1, browser_line2, browser_line3);

    mouse_init();

    for (;;) {
        if (dirty) {
            gui_redraw_desktop(windows, start_menu_open, browser_url);
            if (console.open) {
                gui_console_draw(&console, (COLOR_LIGHT_GREY << 4) | COLOR_WHITE, (COLOR_LIGHT_GREY << 4) | COLOR_BLACK);
            }
            dirty = 0;
            prev_mouse_cell = VGA[prev_mouse_y * VGA_WIDTH + prev_mouse_x];
        }

        if (mouse_x < 0) mouse_x = 0;
        if (mouse_y < 0) mouse_y = 0;
        if (mouse_x >= VGA_WIDTH) mouse_x = VGA_WIDTH - 1;
        if (mouse_y >= VGA_HEIGHT) mouse_y = VGA_HEIGHT - 1;

        if ((size_t)mouse_x != prev_mouse_x || (size_t)mouse_y != prev_mouse_y) {
            VGA[prev_mouse_y * VGA_WIDTH + prev_mouse_x] = prev_mouse_cell;
            prev_mouse_x = (size_t)mouse_x;
            prev_mouse_y = (size_t)mouse_y;
            prev_mouse_cell = VGA[prev_mouse_y * VGA_WIDTH + prev_mouse_x];
        }
        vga_put_entry_at((char)0x10, cursor_color, prev_mouse_x, prev_mouse_y);

        uint8_t status = inb(PORT_KBD_STATUS);
        if (status & 0x01) {
            uint8_t data = inb(PORT_KBD_DATA);
            if (status & 0x20) {
                mouse_packet[mouse_cycle++] = data;
                if (mouse_cycle == 3) {
                    mouse_cycle = 0;
                    int dx = (int)((int8_t)mouse_packet[1]);
                    int dy = (int)((int8_t)mouse_packet[2]);
                    mouse_x += dx;
                    mouse_y -= dy;
                    left_down = (mouse_packet[0] & 0x01) != 0;
                }
            } else {
                uint8_t scancode = data;
                if ((scancode & 0x80) == 0) {
                    if (console.open) {
                        if (scancode == 0x1C) {
                            console.input[console.input_len] = '\0';
                            gui_console_push_line(&console, console.input);
                            gui_console_exec(&console, console.input, &want_shutdown, &want_reboot_gui);
                            console.input_len = 0;
                            console.input[0] = '\0';
                            dirty = 1;
                        } else if (scancode == 0x0E) {
                            if (console.input_len > 0) {
                                console.input_len--;
                                console.input[console.input_len] = '\0';
                                dirty = 1;
                            }
                        } else {
                            char ch = scancode_to_char(scancode);
                            if (ch && console.input_len + 1 < sizeof(console.input)) {
                                console.input[console.input_len++] = ch;
                                console.input[console.input_len] = '\0';
                                dirty = 1;
                            }
                        }
                    } else if (browser_focus) {
                        if (scancode == 0x1C) {
                            char response[256];
                            if (host_fetch_url(browser_url, response, sizeof(response))) {
                                browser_set_lines(browser_line1, browser_line2, browser_line3, response);
                            } else {
                                browser_set_lines(browser_line1, browser_line2, browser_line3, "Brak bridge hosta");
                            }
                            dirty = 1;
                        } else if (scancode == 0x0E) {
                            if (browser_url_len > 0) {
                                browser_url[--browser_url_len] = '\0';
                                dirty = 1;
                            }
                        } else {
                            char ch = scancode_to_char(scancode);
                            if (ch && browser_url_len + 1 < sizeof(browser_url)) {
                                browser_url[browser_url_len++] = ch;
                                browser_url[browser_url_len] = '\0';
                                dirty = 1;
                            }
                        }
                    } else if (scancode == 0x2E) {
                        VGA[prev_mouse_y * VGA_WIDTH + prev_mouse_x] = prev_mouse_cell;
                        vga_clear();
                        return;
                    }
                }
            }
        }

        if (left_down && !prev_left_down) {
            speaker_beep(1200, 12);

            if (point_in_rect(mouse_x, mouse_y, 1, VGA_HEIGHT - 2, 7, 1)) {
                start_menu_open = !start_menu_open;
                dirty = 1;
            }

            if (start_menu_open && point_in_rect(mouse_x, mouse_y, 2, VGA_HEIGHT - 7, 12, 1)) {
                console.open = 1;
                browser_focus = 0;
                start_menu_open = 0;
                dirty = 1;
            }
            if (start_menu_open && point_in_rect(mouse_x, mouse_y, 2, VGA_HEIGHT - 6, 12, 1)) {
                reboot();
            }
            if (start_menu_open && point_in_rect(mouse_x, mouse_y, 2, VGA_HEIGHT - 5, 12, 1)) {
                shutdown_system();
            }
            if (start_menu_open && point_in_rect(mouse_x, mouse_y, 2, VGA_HEIGHT - 4, 12, 1)) {
                windows[3].minimized = 0;
                browser_focus = 1;
                start_menu_open = 0;
                dirty = 1;
            }

            if (point_in_rect(mouse_x, mouse_y, 1, 2, 7, 4)) {
                console.open = 1;
                browser_focus = 0;
                dirty = 1;
            }
            if (point_in_rect(mouse_x, mouse_y, 1, 8, 7, 4)) {
                windows[3].minimized = 0;
                browser_focus = 1;
                dirty = 1;
            }
            if (point_in_rect(mouse_x, mouse_y, 1, 14, 7, 4)) {
                waterfall_mode();
                dirty = 1;
            }

            for (size_t i = 0; i < 4; i++) {
                if (!windows[i].minimized && point_in_rect(mouse_x, mouse_y, windows[i].x + windows[i].w - 4, windows[i].y, 3, 1)) {
                    windows[i].minimized = 1;
                    drag_index = -1;
                    if (i == 3) {
                        browser_focus = 0;
                    }
                    dirty = 1;
                } else if (!windows[i].minimized && point_in_rect(mouse_x, mouse_y, windows[i].x, windows[i].y, windows[i].w, 1)) {
                    drag_index = (int)i;
                    drag_off_x = mouse_x - (int)windows[i].x;
                    drag_off_y = mouse_y - (int)windows[i].y;
                    drag_new_x = (int)windows[i].x;
                    drag_new_y = (int)windows[i].y;
                    drag_pending = 0;
                }
            }

            size_t tx = 1;
            for (size_t i = 0; i < 4; i++) {
                if (windows[i].minimized) {
                    size_t item_len = strlen(windows[i].title) + 2;
            if (point_in_rect(mouse_x, mouse_y, tx, VGA_HEIGHT - 1, item_len, 1)) {
                        windows[i].minimized = 0;
                        if (i == 3) {
                            browser_focus = 1;
                        }
                        dirty = 1;
                    }
                    tx += item_len + 1;
                }
            }

            if (!windows[3].minimized && point_in_rect(mouse_x, mouse_y, windows[3].x, windows[3].y, windows[3].w, windows[3].h)) {
                browser_focus = 1;
                console.open = 0;
            }
        }

        if (left_down && drag_index >= 0) {
            GuiWindow* w = &windows[drag_index];
            int nx = mouse_x - drag_off_x;
            int ny = mouse_y - drag_off_y;
            if (nx < 0) nx = 0;
            if (ny < 0) ny = 0;
            if (nx > (int)(VGA_WIDTH - w->w)) nx = (int)(VGA_WIDTH - w->w);
            if (ny > (int)(VGA_HEIGHT - 3 - w->h)) ny = (int)(VGA_HEIGHT - 3 - w->h);
            drag_new_x = nx;
            drag_new_y = ny;
            drag_pending = 1;
        }

        if (!left_down) {
            if (drag_index >= 0 && drag_pending) {
                windows[drag_index].x = (size_t)drag_new_x;
                windows[drag_index].y = (size_t)drag_new_y;
                dirty = 1;
            }
            drag_pending = 0;
            drag_index = -1;
        }
        prev_left_down = left_down;

        if (want_reboot_gui) {
            gui_reset_windows(windows, browser_line1, browser_line2, browser_line3);
            browser_url[0] = '\0';
            browser_url_len = 0;
            browser_focus = 0;
            console.open = 0;
            console.line_count = 0;
            console.input_len = 0;
            console.input[0] = '\0';
            want_reboot_gui = 0;
            dirty = 1;
        }
        if (want_shutdown) {
            shutdown_system();
        }

        delay_approx_ms(15);
    }
}

static void execute_command(const char* command) {
    if (strcmp(command, "help") == 0) {
        puts("Dostepne komendy:\n");
        puts("  help            - pokazuje te pomoc\n");
        puts("  clear / cls     - czysci ekran\n");
        puts("  echo X          - wypisuje tekst X\n");
        puts("  reboot          - restartuje maszyne (QEMU)\n");
        puts("  shutdown        - zatrzymuje system\n");
        puts("  panic POWOD     - panic + auto reboot po 5s\n");
        puts("  waterfall       - matrix rainbow (C = wyjscie)\n");
        puts("  cpuinfo         - pokazuje prawdziwe dane CPU\n");
        puts("  version         - wersja systemu\n");
        puts("  rand            - losowa liczba 0..99999\n");
        puts("  gui             - fake desktop z oknami (C = wyjscie)\n");
        puts("  browser URL     - pobiera strone przez host bridge\n");
        return;
    }

    if (strcmp(command, "clear") == 0 || strcmp(command, "cls") == 0) {
        vga_clear();
        return;
    }

    if (starts_with(command, "echo")) {
        if (command[4] == ' ') {
            puts(command + 5);
        }
        putchar('\n');
        return;
    }

    if (strcmp(command, "reboot") == 0) {
        reboot();
        return;
    }

    if (strcmp(command, "shutdown") == 0) {
        shutdown_system();
        return;
    }

    if (starts_with(command, "panic")) {
        const char* reason = "";
        if (command[5] == ' ') {
            reason = command + 6;
        }
        panic_screen(reason);
        return;
    }

    if (strcmp(command, "waterfall") == 0) {
        waterfall_mode();
        return;
    }

    if (strcmp(command, "cpuinfo") == 0) {
        print_cpu_info();
        return;
    }

    if (strcmp(command, "gui") == 0) {
        gui_mode();
        return;
    }

    if (strcmp(command, "version") == 0) {
        puts("broOS 0.3-dev\n");
        return;
    }

    if (strcmp(command, "rand") == 0) {
        char num[16];
        u32_to_dec(rng_next() % 100000u, num, sizeof(num));
        puts(num);
        putchar('\n');
        return;
    }

    if (starts_with(command, "browser ") && strlen(command) > 8) {
        char page[512];
        if (host_fetch_url(command + 8, page, sizeof(page))) {
            puts(page);
            putchar('\n');
        } else {
            puts("Brak odpowiedzi hosta. Uruchom mostek host->COM1.\n");
            puts("Protokol: wyslij 'GET <url>\\n', zakoncz odpowiedz bajtem 0x04.\n");
        }
        return;
    }

    if (strlen(command) > 0) {
        puts("Nieznana komenda. Wpisz: help\n");
    }
}

void kmain(void) {
    char cmd[CMD_BUF_SIZE];
    size_t len = 0;

    vga_clear();
    vga_set_color(VGA_INFO_COLOR);
    puts("broOS kernel shell\n");
    vga_set_color(VGA_DEFAULT_COLOR);

    if (keyboard_detect()) {
        vga_set_color(VGA_INFO_COLOR);
        puts("[OK] Wykryto kontroler klawiatury PS/2\n");
    } else {
        vga_set_color((COLOR_BLUE << 4) | COLOR_WHITE);
        puts("[ERR] Nie wykryto klawiatury\n");
    }

    puts("Start GUI...\n");
    serial_init();
    speaker_beep(880, 80);
    speaker_beep(1320, 100);
    transition_animation("Launching broOS GUI...", (COLOR_BLUE << 4) | COLOR_WHITE);
    gui_mode();

    vga_set_color(VGA_DEFAULT_COLOR);
    puts("Wpisz 'help', aby zobaczyc komendy.\n\n");
    print_prompt();

    for (;;) {
        uint8_t scancode;
        if (!keyboard_try_read_scancode(&scancode)) {
            continue;
        }

        if (scancode & 0x80) {
            continue;
        }

        if (scancode == 0x1C) {
            putchar('\n');
            cmd[len] = '\0';
            execute_command(cmd);
            len = 0;
            print_prompt();
            continue;
        }

        if (scancode == 0x0E) {
            if (len > 0) {
                len--;
                if (cursor_col == 0 && cursor_row > 0) {
                    cursor_row--;
                    cursor_col = VGA_WIDTH - 1;
                } else if (cursor_col > 0) {
                    cursor_col--;
                }
                vga_put_entry_at(' ', active_color, cursor_col, cursor_row);
            }
            continue;
        }

        char c = scancode_to_char(scancode);
        if (c && len + 1 < CMD_BUF_SIZE) {
            cmd[len++] = c;
            putchar(c);
        }
    }
}
